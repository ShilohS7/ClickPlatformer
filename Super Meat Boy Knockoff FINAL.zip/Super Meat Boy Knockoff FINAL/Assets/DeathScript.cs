using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathScript : MonoBehaviour
{

    private Animator animation;
    
    public bool dead = false;
    [SerializeField] private string hitAnimation = "";
    [SerializeField] public bool saveable = false;
    public string saveInfo;


    // Start is called before the first frame update
    void Start()
    {
        save();
        animation = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (dead)
        {
            if (saveable)
            {
                load();
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }


    public void hit()
    {
        if (hitAnimation != "")
        {
            animation.Play(hitAnimation);
        }
    }

    public void save()
    {
        if (saveable)
        {
            dead = false;
            saveInfo = JsonUtility.ToJson(transform.position);
        }
    }
    
    private void load()
    {
        dead = false;
        transform.position = JsonUtility.FromJson<Vector3>(saveInfo);
    }
}
