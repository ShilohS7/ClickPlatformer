using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wander_and_Target : MonoBehaviour
{
    
    private string state = "wander";
    [SerializeField] private GameObject target;
    private Rigidbody2D rBody;
    [SerializeField] private float targetRadius;
    [SerializeField] private float acceleration;
    private int timer = 0;
    [SerializeField] private float chaseSpeed = 60;
    [SerializeField] private float wanderSpeed = 200;
    [SerializeField] private int wanderInterval = 20;

    // Start is called before the first frame update
    void Start()
    {
        rBody = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        switch (state)
        {
            case "wander":
                wander_state();
                break;
            case "target":
                target_state();
                break;
        }
    }

    private void target_state()
    {
        Vector3 forces = Vector3.zero;
        if (target != null)
        {
            Vector3 pos = target.transform.position;
            if (!withinRange(pos))
            {
                state = "wander";
            }
            forces = (forces + (pos - transform.position)) / 2;
        }
        rBody.AddForce(forces * chaseSpeed * Time.deltaTime);
    }

    private void wander_state()
    {
        if (target != null)
        {
            Vector3 pos = target.transform.position;
            if (withinRange(pos))
            {
                state = "target";
            }
            else if(timer == 0)
            {
                Vector3 forces = new Vector3();

                if (Random.value > 0.5f)
                {
                    forces += Vector3.left;
                }

                else if (Random.value > 0.5f)
                {
                    forces += Vector3.right;
                }

                if (Random.value > 0.5f)
                {
                    forces += Vector3.up;
                }

                else if (Random.value > 0.5f)
                {
                    forces += Vector3.down;
                }
                rBody.AddForce(forces * wanderSpeed * Time.deltaTime);
            }
        }

        timer += 1;
        if (timer > wanderInterval)
        {
            timer = 0;
        }
    }

    bool withinRange(Vector3 dest)
    {
        return Vector3.Distance(dest, transform.position) <= targetRadius;
    }
}
