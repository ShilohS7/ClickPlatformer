using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CameraFollow : MonoBehaviour
{
    [SerializeField] public GameObject player;
    private Rigidbody2D rBody;
    public float cameraHeight = -10.0f;
    public float cameraY = 0;
    public float cameraX = -1;
    [SerializeField] private float cameraSpeed;

    private void Start()
    {
        rBody = gameObject.GetComponent<Rigidbody2D>();
    }

    void Update() {
        if (player != null)
        {
            Vector3 pos = player.transform.position;
            pos.y += cameraY;
            pos.x += cameraX;
            pos.z += cameraHeight;
        
            Vector3 force = pos - transform.position;
            rBody.AddForce(force * cameraSpeed * Time.deltaTime * 60); //adds some camera delay that helps convey speed
        }
    }
}