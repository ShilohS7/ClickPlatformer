using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConditionGate : MonoBehaviour
{

    public GameObject[] watchDespawn;

    private bool trigger = false;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < watchDespawn.Length; i++)
        {
            trigger = true;
            GameObject obj = watchDespawn[i];
            if (obj != null)
            {
                trigger = false;
                return;
            }
        }

        if (trigger)
        {
            Destroy(gameObject);
        }
    }
}
