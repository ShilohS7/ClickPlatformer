using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private Sprite cloudSprite;
    [SerializeField] private float cloudHeight;
    [SerializeField] private float cloudDrag;
    
    private bool cloudy = false;
    private Rigidbody2D rBody;
    private SpriteRenderer spriteR;
    [SerializeField] private Sprite groundSprite;
    [SerializeField] private Sprite airSprite;
    private float normalDrag;
    private bool grounded;
    
    [SerializeField] private Vector3 originDisplacement = Vector3.down * 2;
    [SerializeField] private float moveSpeed = 0.01f;
    [SerializeField] private float jumpAcceleration = 500;
    [SerializeField] private float moveAcceleration = 1;
    [SerializeField] private float groundRadius = 0.2f;
    private LayerMask groundMask;

    private void Start()
    {
        cloudy = false;
        grounded = false;
        rBody = gameObject.GetComponent<Rigidbody2D>();
        normalDrag = rBody.drag;
        spriteR = GetComponent<SpriteRenderer>();
        groundMask = 1 << LayerMask.NameToLayer ("Ground"); //get ground layer
    }

    void Update()
    {
        grounded = Physics2D.OverlapCircle(transform.position, groundRadius, groundMask);

        if (grounded)
        {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                rBody.AddForce(Vector2.left * moveAcceleration);
            }
            if (Input.GetKey(KeyCode.RightArrow))
            {
                rBody.AddForce(Vector2.right * moveAcceleration);
            }
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                rBody.AddForce(Vector2.up * jumpAcceleration);
            }
        }
        
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position += Vector3.left * moveSpeed;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += Vector3.right * moveSpeed;
        }


        RaycastHit2D rHit = Physics2D.Raycast(transform.position + originDisplacement, Vector3.down, cloudHeight);

        if (rHit)
        {
            if (!cloudy)
            {
                startCloud();
            }
        }
        else
        {
            if (cloudy)
            {
                endCloud();
            }
        }

        if (grounded)
        {
            spriteR.sprite = groundSprite;
        }
        else
        {
            if (cloudy)
            {
                spriteR.sprite = cloudSprite;
            }
            else
            {
                spriteR.sprite = airSprite;
            }
        }
    }

    void startCloud()
    {
        spriteR.sprite = cloudSprite;
        cloudy = true;
        rBody.drag = cloudDrag;
    }

    void endCloud()
    {
        if (grounded)
        {
            spriteR.sprite = groundSprite;
        }
        else
        {
            spriteR.sprite = airSprite;
        }
        cloudy = false;
        rBody.drag = normalDrag;
    }

    void OnCollisionEnter()
    {
        endCloud();
    }
}
