using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackHandler : MonoBehaviour
{
    public int id = 1;
    public GameObject hitboxPrefab;
    public GameObject bulletPrefab;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void makeHitbox(int damage, int duration, float scale)
    {
        var hitbox = Instantiate(hitboxPrefab);
        var hMain = hitbox.GetComponent<HitboxMain>();
        hMain.id = id;
        hMain.duration = duration;
        hMain.damage = damage;
        hitbox.transform.localScale *= scale;
        Instantiate(hitbox, transform.position, Quaternion.identity);
    }
    public void makeHitbox(int damage, int duration, float scale, Vector3 offset)
    {
        var hitbox = Instantiate(hitboxPrefab);
        var hMain = hitbox.GetComponent<HitboxMain>();
        hMain.id = id;
        hMain.duration = duration;
        hMain.damage = damage;
        hitbox.transform.localScale *= scale;
        Instantiate(hitbox, transform.position + offset, Quaternion.identity);
    }

    public void makeBullet(int damage, int duration, float scale, Vector3 direction)
    {
        var bullet = Instantiate(bulletPrefab);
        var rBody = bullet.GetComponent<Rigidbody2D>();
        var bMain = bullet.GetComponent<BulletMain>();
        bMain.id = id;
        bMain.duration = duration;
        bMain.damage = damage;
        bullet.transform.localScale *= scale;
        Instantiate(bullet, transform.position + direction, Quaternion.identity);
    }

    public void makeBullet(int damage, int duration, float scale, Vector3 direction, float speed)
    {
        var bullet = Instantiate(bulletPrefab);
        var bMain = bullet.GetComponent<BulletMain>();
        bMain.id = id;
        bMain.duration = duration;
        bMain.damage = damage;
        bullet.transform.localScale *= scale;
        GameObject i = Instantiate(bullet, transform.position + direction, Quaternion.identity);
        var rBody = i.GetComponent<Rigidbody2D>();
        rBody.AddForce( direction * speed);
    }
}
