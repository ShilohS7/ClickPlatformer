using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletMain : MonoBehaviour
{
    [SerializeField] public int duration = -1; //-1 means infinite duration, only used for debugging
    [SerializeField] public int id = 0;
    [SerializeField] public float damage = 1;
    //despawn = ds
    public bool wall_ds = true;
    public bool hit_ds = true;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (duration == 0)
        {
            Destroy(gameObject);
        }
        else if (duration > 0)
        {
            duration -= 1;
        }
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        GameObject obj = col.gameObject;
        switch (obj.tag)
        {
            case "Hurtbox":
                var hurtbox = obj.GetComponent<HurtboxMain>();
                if (hurtbox.id != id)
                {
                    hurtbox.hp -= damage;
                    if (hit_ds)
                    {
                        duration = 0;
                    }
                }
                
                if ( hurtbox.hp <= 0)
                {
                    var dScript = obj.GetComponent<DeathScript>();
                    if (dScript)
                    {
                        dScript.dead = true;
                    }
                }
                
                break;
            case "Wall":
                if (wall_ds)
                {
                    duration = 0;
                }

                break;
        }
    }
}