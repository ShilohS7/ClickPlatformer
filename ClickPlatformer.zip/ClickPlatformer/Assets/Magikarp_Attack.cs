using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magikarp_Attack : MonoBehaviour
{
    private int timer = 0;
    private AttackHandler attack;

    [SerializeField] private int attackTick = 360;

    // Start is called before the first frame update
    void Start()
    {
        attack = GetComponent<AttackHandler>();
    }

    // Update is called once per frame
    void Update()
    {
        if ((int)(timer / attackTick) != 0)
        {
            for (float i = 0; i < 4; i+= 1)
            {
                attack.makeBullet(2, 1800, 1f, new Vector2(Mathf.Sin(i/2f * Mathf.PI),Mathf.Cos(i/2f * Mathf.PI)) * 0.4f, .2f);
            }

            timer = 0;
        }

        timer += 1;
    }
}
