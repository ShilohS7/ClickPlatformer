using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HurtboxMain : MonoBehaviour
{
    [SerializeField] public int id = 0;
    [SerializeField] public float hp = 0;
    [SerializeField] private Text HPDisplay;


    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void takeDamage(float damage)
    {
        hp -= damage;
        if (HPDisplay != null)
            if (hp > 0)
            {
                HPDisplay.text = hp + "";
            }
            else
            {
                HPDisplay.text = "10"; //respawn health
            }
    }
}
