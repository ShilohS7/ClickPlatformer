using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class PlayerMain : MonoBehaviour
{
    //standard variables
    private AttackHandler attack;
    private Rigidbody2D rBody;
    private SpriteRenderer sprite;
    private Animator animation;

    /**Player moves by attacking in direction of mouse click.
     * Different directions result in different attack:
     * Upwards attack (U), Horizontal attack (H), Downwards attack (D), Diagonal Upwards attack (V), Downwards diagonal attack (A)
     *
     * states include:
     * N: normal/idle state
     * S: stun state
     * and attack states: U,H,D,V,A
     */

    //state machine variables
    private char state = 'N';
    private int timer = 0;
    private bool leftFace = false;
    private bool grounded = false;
    
    private LayerMask groundMask;
    
    [SerializeField] private float groundRadius = 0.11f;
    [SerializeField] private float playerWidth = 0.12f;
    private int U_count = 0;
    private int V_count = 0;
    [SerializeField] private int max_Us = 1;
    [SerializeField] private int max_Vs = 2;
    [SerializeField] private Vector3 originDisplacement;

    // Start is called before the first frame update
    void Start()
    {
        attack = GetComponent<AttackHandler>();
        sprite = GetComponent<SpriteRenderer>();
        animation = GetComponent<Animator>();
        animation.Play("Megaman_Air_Idle");
        state = 'N';
        timer = 0;
        groundMask = 1 << LayerMask.NameToLayer ("World");
        rBody = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Time.timeScale = 0;
        }

        if (leftFace)
        {
            sprite.flipX = false;
        }
        else
        {
            sprite.flipX = true;
        }

        var origin = transform.position + originDisplacement;
        //will add leaning over ledge animation later if only one ray is true
        grounded = Physics2D.Raycast(origin, Vector3.down, groundRadius, groundMask) | Physics2D.Raycast(origin + Vector3.left * playerWidth, Vector3.down, groundRadius, groundMask) | Physics2D.Raycast(origin + Vector3.right * playerWidth, Vector3.down, groundRadius, groundMask);
        
        switch (state)
        {
            case 'N':
                normal_state();
                break;
            case 'S':
                hitStun_state();
                break;
            case 'U':
                upAttack();
                break;
            case 'D':
                downAttack();
                break;
            case 'H':
                sideAttack();
                break;
            case 'V':
                upSideAttack();
                break;
            case 'A':
                downSideAttack();
                break;
        }

        if (grounded)
        {
            if (state == 'N')
            {
                U_count = 0;
                V_count = 0;
            }
        }

        timer += 1; //move to next frame, decided not to use delta time, would use (Mathf.Max((int)(Time.deltaTime * 60), 1)) if I changed my mind
    }

    private void normal_state()
    {
        if (animation.GetCurrentAnimatorStateInfo(0).normalizedTime > 1)
        {
            if(grounded)
                animation.Play("Megaman_Idle");
            else
            {
                animation.Play("Megaman_Air_Idle");
            }
        }
        if (Input.GetMouseButton(0) || Input.GetMouseButton(1))
        {
            float angle = getAngleToMouse();
            state = getInputChar(angle);
            if (state == 'U')
            {
                U_count += 1;
                if (U_count > max_Us)
                    state = 'N'; //run out of jumps
            }
            else if (state == 'V')
            {
                V_count += 1;
                if (V_count > max_Vs)
                    state = 'N'; //run out of side jumps
            }
        }
        timer = 0;
    }

    private char getInputChar(float angle)
    {
        if (angle > 0)
        {
            if (angle <= 120)
            {
                if (angle <= 20)
                    return 'U';
                if (angle <= 60)
                {
                    leftFace = false;
                    return 'V'; //ur
                }
                else
                {
                    leftFace = false;
                    return 'H'; //r
                }
            }
            else if (angle <= 210)
            {
                if (angle <= 150)
                {
                    leftFace = false;
                    return 'A'; //dr
                }
                else
                    return 'D';
            }
            else
            {
                if (angle <= 240)
                {
                    leftFace = true;
                    return 'A'; //dl
                }
                else
                {
                    leftFace = true;
                    return 'H'; //l
                }
            }
        }
        else
        {
            if (angle > -20)
            {
                return 'U';
            }
            else if (angle >= -60)
            {
                leftFace = true;
                return 'V'; //ul
            }
            else
            {
                leftFace = true;
                return 'H'; //l
            }
        }

        return 'N';
    }

    private float getAngleToMouse(bool positive = false, bool printOut = false)
    {
        //Get screen positions of player and mouse
        Vector2 positionOnScreen = Camera.main.WorldToViewportPoint (transform.position);
        Vector2 mouseOnScreen = (Vector2)Camera.main.ScreenToViewportPoint(Input.mousePosition);
         
        //Get the angle between the points
        float angle = AngleBetweenTwoPoints(positionOnScreen, mouseOnScreen);

        angle = angle % 360;
        
        if (positive)
        {
            //make angle positive always
            if (angle < 0)
                angle += 360;
        }

        if (printOut)
        {
            print(angle);
        }
        
        return angle;
    }
 
    float AngleBetweenTwoPoints(Vector3 a, Vector3 b, float offset = 90) //offset to make angle more intuitive, with 0 degrees being directly upwards as supposed to to the left.
    {
        return Mathf.Atan2(a.y - b.y, a.x - b.x) * Mathf.Rad2Deg + offset;
    }
    
    private void hitStun_state()
    {
        throw new System.NotImplementedException();
    }
    
    private void setAnimation(string stateName)
    {
        animation.Play(stateName);
    }
    
    //attacks
    private void upAttack()
    {
        if (timer >= 61)
        {
            state = 'N';
        }
        if (timer == 61)
        {
            attack.makeHitbox(4, 8, .8f, Vector3.up * 2);
            attack.makeHitbox(3, 10, .6f, Vector3.left * 0.6f + Vector3.up * 1.4f);
            attack.makeHitbox(3, 10, .6f, Vector3.right * 0.6f + Vector3.up * 1.4f);
        }
        else if (timer == 32)
        {
            attack.makeHitbox(8, 14, 2f);
            setAnimation("Megaman_TwirlJump");
            Vector2 v = rBody.velocity;
            v.y = 0;
            rBody.velocity = v;
            rBody.AddForce(Vector3.up * 1000);
        }
        else if(timer < 32)
        {
            animation.Play("Megaman_Startup_1");
        }
    }

    private void downAttack()
    {
        if (timer >= 38)
        {
            for (float i = 0; i < 8; i+= 1)
            {
                attack.makeBullet(2, 1800, 1f, new Vector2(Mathf.Sin(i/4f * Mathf.PI),Mathf.Cos(i/4f * Mathf.PI)) * 0.4f, .2f);
            }
            state = 'N';
        }
        else if (timer == 1)
        {
            setAnimation("Megaman_Beam");
            rBody.velocity = Vector2.ClampMagnitude(rBody.velocity, 500);
            rBody.AddForce(Vector3.down * 1000);
        }
        else if ((int)(timer / 8) == 0)
        {
            attack.makeHitbox(1, 4, .6f);
        }
    }
    private void sideAttack()
    {
        if (timer >= 20)
        {
            state = 'N';
        }
        else
        {
            if (timer == 1)
            {
                attack.makeHitbox(2, 20, 0.4f);
                setAnimation("Megaman_Slide");
                rBody.velocity = Vector2.zero;
                if (leftFace)
                {
                    attack.makeHitbox(3, 16, 1.2f, Vector3.right * 1.3f);
                    rBody.AddForce(Vector3.right * 500);
                }
                else
                {
                    attack.makeHitbox(3, 16, 1.2f, Vector3.left * 1.3f);
                    rBody.AddForce(Vector3.left * 500);
                }
            }
        }
    }
    private void upSideAttack()
    {
        if (timer >= 30)
        {
            state = 'N';
        }
        else if (timer == 30)
        {
            attack.makeHitbox(1, 12, .4f, Vector3.up * 1.6f);
        }
        else if (timer == 12)
        {
            attack.makeHitbox(1, 6, .8f, Vector3.up * 1.2f);
        }
        else if (timer == 6)
        {
            attack.makeHitbox(1, 6, 1f, Vector3.up * 1.2f);
        }
        else if (timer == 1)
        {
            attack.makeHitbox(3, 3, 1.2f, Vector3.up);
            setAnimation("Megaman_Leap");
            rBody.AddForce(Vector3.up * 300);
            if (leftFace)
            {
                rBody.AddForce(Vector3.right * 250);
            }
            else
            {
                rBody.AddForce(Vector3.left * 250);
            }
        }
    }
    private void downSideAttack()
    {
        if (timer >= 26)
        {
            float bullet_count = 2;
            for (float i = 0.5f; i < bullet_count + 0.5f; i++)
            {
                attack.makeBullet(4, 32, 1f, new Vector2(Mathf.Sin(i/bullet_count * Mathf.PI * 2),Mathf.Cos(i/bullet_count * Mathf.PI * 2)) * 0.4f,0.03f);
            }
            state = 'N';
        }
        else if (timer == 20)
        {
            rBody.AddForce(Vector3.down * -25);
            if (leftFace)
            {
                rBody.AddForce(Vector3.right * -35);
            }
            else
            {
                rBody.AddForce(Vector3.left * -35);
            }
        }
        else if (timer >= 10 && timer <= 15)
        {
            rBody.velocity /= 1.2f;
        }
        else if (timer <= 5)
        {
            setAnimation("Megaman_TwirlBlast");
            rBody.AddForce(Vector3.down * 100);
            if (leftFace)
            {
                rBody.AddForce(Vector3.right * 100);
            }
            else
            {
                rBody.AddForce(Vector3.left * 100);
            }
        }
    }
}
