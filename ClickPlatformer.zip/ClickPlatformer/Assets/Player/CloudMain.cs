using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudMain : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnCollisionEnter2D(Collision2D hit)
    {
        if (hit.gameObject.tag == "Ground")
        {
            set_active(false);
        }
    }

    private void set_active(bool b)
    {
        gameObject.active = b;
    }
}
