using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitboxMain : MonoBehaviour
{
    [SerializeField] public bool visible = true;
    [SerializeField] public int duration = -1; //-1 means infinite duration, only used for debugging
    [SerializeField] public int id = 0;
    [SerializeField] public float damage = 1;

    // Start is called before the first frame update
    void Start()
    {
        if (!visible)
        {
            GetComponent<SpriteRenderer>().enabled = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (duration == 0)
        {
            Destroy(gameObject);
        }
        else if (duration > 0)
        {
            duration -= 1;
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        GameObject obj = col.gameObject;
        switch (obj.tag)
        {
            case "Hurtbox":
                var hurtbox = obj.GetComponent<HurtboxMain>();
                var dScript = obj.GetComponent<DeathScript>();
                if (hurtbox.id != id)
                    if (damage > 0)
                    {
                        hurtbox.takeDamage(damage);
                        dScript.hit();
                    }
                    else
                    {
                        //checkpoint
                        hurtbox.takeDamage(damage);
                        dScript.save();
                        Destroy(gameObject);
                    }
                if ( hurtbox.hp <= 0)
                    {
                        dScript.dead = true;
                        if (dScript.saveable)
                        {
                            hurtbox.hp = 10; //respawns with 10 hp
                        }
                    }
                break;
        }
    }
}
