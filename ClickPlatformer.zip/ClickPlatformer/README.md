# ClickPlatformer

Art assets are from the following games:
Mega Man 2
Super Mario Land
Terraria
Undertale
